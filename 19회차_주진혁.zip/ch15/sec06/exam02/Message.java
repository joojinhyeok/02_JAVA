package ch15.sec06.exam02;

import lombok.AllArgsConstructor;

@AllArgsConstructor

public class Message {
    public String command;
    public String to;
}
