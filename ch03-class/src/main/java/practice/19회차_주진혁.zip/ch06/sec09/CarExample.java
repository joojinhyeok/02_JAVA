package main.java.practice.ch06.sec09;

public class CarExample {
    public static void main(String[] args) {
        Car myCar = new Car("그랜저");
        myCar.setSpeed(120);
        myCar.run();
    }
}
