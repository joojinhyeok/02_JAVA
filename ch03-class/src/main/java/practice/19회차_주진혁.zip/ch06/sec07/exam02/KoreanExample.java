package main.java.practice.ch06.sec07.exam02;

public class KoreanExample {
    public static void main(String[] args) {
        // Korean 객체 생성
        Korean myKorean = new Korean("박자바", "011225-1234567");
        // 또 다른 Korean 객체 생성
        Korean myKorean2 = new Korean("김자바", "930525-0654321");
    }
}
