package main.java.practice.ch06.sec06.exam01;

public class Car {
    //필드 선언
    String model;   // null
    String color;
//    boolean start;  //false
    int speed;  // 0


    public Car(String model, String color, int speed){
        this.model = model;
        this.color = color;
        this.speed = speed;
    }
}
