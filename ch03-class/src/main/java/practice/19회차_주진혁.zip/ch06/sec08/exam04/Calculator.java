package main.java.practice.ch06.sec08.exam04;

public class Calculator {
    public double areaRectangle(int x){
        return (double) x * x;
    }
    public double areaRectangle(int x, int y){
        return (double) x * y;
    }
}
